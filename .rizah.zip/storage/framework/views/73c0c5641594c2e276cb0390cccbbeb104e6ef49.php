<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('admin.Alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <h2 class="card-title">Employee Information</h2>

        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">


                        <form class="forms-sample" method="POST" action=" <?php echo e(route('employee.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Name</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="name" class="form-control" style="padding: .500rem"
                                        placeholder="Name">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:.6rem">
                                    <p>Designation</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="employee_id" class="form-control" style="padding: .500rem"
                                        placeholder="Designation">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Email</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="email" name="email" class="form-control" style="padding: .500rem"
                                        placeholder="Email">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%;">
                                    <p>Present Address</p>
                                </div>
                                <div class="col-sm-7" >
                                    <input type="text" name="present" class="form-control" style="padding: .500rem"
                                        placeholder="Present Address">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%;">
                                    <p>Permanent Address</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="permanent" class="form-control" style="padding: .500rem"
                                        placeholder="Permanent Address">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Phone Number</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="tel" name="phone" class="form-control" style="padding: .500rem"
                                        placeholder="Phone No">
                                </div>
                            </div>

                            

                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Facebook</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="facebook" class="form-control" style="padding: .500rem"
                                        placeholder="Facebook">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Instragram</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="instragram" class="form-control" style="padding: .50rem"
                                        placeholder="Instragram">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Twitter</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="twitter" class="form-control" style="padding: .50rem"
                                        placeholder="Twitter">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width:40%; padding-top:10px">
                                    <p>Skype</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="text" name="skype" class="form-control" style="padding: .50rem"
                                        placeholder="Twitter">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-4" style="max-width: 40%;">
                                    <p>Image</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="file" name="image" accept="image/*" onchange="readURL(this)" />
                                </div>
                            </div>
                            <img id="img-preview" src="<?php echo e(asset('images/noimage.jpg')); ?>" width="220px" height="150px" style="margin-left: 22.5rem" />
                    </div>
                </div>
            </div>
        </div>
        <div class="btn" style="padding-top: 30px; padding-left:0%">
            <button type="submit" class="btn btn-primary mr-2">Submit</button>
            <button class="btn btn-light">Cancel</button>
        </div>

        </form>



    </div>
    <!-- content-wrapper ends -->

    <!-- main-panel ends -->

    <div class="content-wrapper">
        <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Employee List</h4>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Employee Id</th>
                                    <th>Email</th>
                                    <th>Present Address</th>
                                    <th>Permanent Address</th>
                                    <th>Phone No</th>
                                    
                                    <th>Facebook</th>
                                    <th>Instragram</th>
                                    <th>Twitter</th>
                                    <th>Skype</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->name); ?></td>
                                        <td><?php echo e($item->employee_id); ?></td>
                                        <td><?php echo e($item->email); ?></td>
                                        <td><?php echo e($item->present); ?></td>
                                        <td><?php echo e($item->permanent); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                        
                                        <td><?php echo e($item->facebook); ?></td>
                                        <td><?php echo e($item->instragram); ?></td>
                                        <td><?php echo e($item->twitter); ?></td>
                                        <td><?php echo e($item->skype); ?></td>
                                        <td><img src="<?php echo e(asset('images/' . $item->image)); ?>" alt=""></td>
                                        <td> <a href="<?php echo e(route('employee.edit', $item->id)); ?>"><i
                                            class="fa-solid fa-pen"></i> </a></td>
                                        <td><a href="<?php echo e(route('employee.delete', $item->id)); ?>" onclick=" return confirm('Are You Sure!') "><i
                                            class="fa-solid fa-trash"></i></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo $employee->withQueryString()->links('pagination::bootstrap-5'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>


    <!-- base:js -->
<?php $__env->stopSection(); ?>



<?php $__env->startPush('admin-js'); ?>
    <script>
        let noimage =
            "https://ami-sni.com/wp-content/themes/consultix/images/no-image-found-360x250.png";

        function readURL(input) {
            console.log(input.files);
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $("#img-preview").attr("src", e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            } else {
                $("#img-preview").attr("src", noimage);
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rizah\resources\views/employee/index.blade.php ENDPATH**/ ?>