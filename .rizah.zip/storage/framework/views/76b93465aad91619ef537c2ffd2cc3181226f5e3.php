<?php $__env->startSection('web-master'); ?>


<div class="page_header_default style_one ">
    <div class="parallax_cover">
       <div class="simpleParallax"><img src="<?php echo e(asset('images/'.$banner->service)); ?>" alt="bg_image"
             class="cover-parallax"></div>
    </div>
    <div class="page_header_content">
       <div class="auto-container">
          <div class="row">
             <div class="col-md-12">
                <div class="banner_title_inner">
                   <div class="title_page">
                      Service Default
                   </div>
                </div>
             </div>
             <div class="col-lg-12">
                <div class="breadcrumbs creote">
                   <ul class="breadcrumb m-auto">
                      <li><a href="index-2.html">Home</a></li>
                      <li class="active">Service Default</li>
                   </ul>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!----header----->


 <div id="content" class="site-content ">
    <!--===============spacing==============-->
    <div class="pd_top_90"></div>
    <!--===============spacing==============-->
    <section class="creote-service-box">
       <div class="container">
          <div class="row">
            <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


             <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-xs-12">
                <div class="service_post style_one">
                   <div class="image">
                      <div class="overlay"></div>
                      <img loading="lazy" width="500" height="500" src="assets/images/service/service-image-6.jpg"
                         alt="img">
                   </div>
                   <div class="service_content icon_yes">
                      <div class="icon_box">
                         <span class="icon icon-thumbs-up icon"></span>
                      </div>
                      <h2 class="title_service"><a href="#" rel="bookmark"><?php echo e($item->title); ?></a></h2>
                      <p class="short_desc"> <?php echo Str::limit($item->details, 60, ' ...'); ?> </p>
                      <a class="read_more" href="#"> Read More<i class="icon-right-arrow-long"></i></a>
                   </div>
                </div>
             </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             
          </div>
       </div>
    </section>
    <!--===============spacing==============-->
    <div class="pd_top_80"></div>
    <!--===============spacing==============-->
   
 </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rizah\resources\views/frontend/service.blade.php ENDPATH**/ ?>