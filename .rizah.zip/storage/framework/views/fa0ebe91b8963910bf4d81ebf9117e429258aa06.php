<?php $__env->startSection('web-master'); ?>

<div class="page_header_default style_one ">
    <div class="parallax_cover">
       <div class="simpleParallax">
          <img src="<?php echo e(asset('images/'.$banner->team)); ?>" alt="bg_image" class="cover-parallax">
       </div>
    </div>
    <div class="page_header_content">
       <div class="auto-container">
          <div class="row">
             <div class="col-md-12">
                <div class="banner_title_inner">
                   <div class="title_page">
                      Our Team
                   </div>
                </div>
             </div>
             <div class="col-lg-12">
                <div class="breadcrumbs creote">
                   <ul class="breadcrumb m-auto">
                      <li><a href="index-2.html">Home</a></li>
                      <li class="active">Our Team</li>
                   </ul>
                </div>
             </div>
          </div>
       </div>
    </div>
 </div>
 <!----header----->
 <!----page-CONTENT----->
 <div id="content" class="site-content ">
    <!---team intro--->
    
       <!--===============spacing==============-->
       
       <!--===============spacing==============-->
       
    <!---team intro--->
    <!---image box section--->
    
       <!--===============spacing==============-->
       
       <!--===============spacing==============-->
       
       <!--===============spacing==============-->
       
       <!--===============spacing==============-->
    
    <!---image box section--->
    <!---team section--->
    <section class="team-section bg_light_1">
       <!--===============spacing==============-->
       <div class="pd_top_90"></div>
       <!--===============spacing==============-->
       <div class="container">
          <div class="row">
             <div class="col-lg-12">
                <div class="title_all_box style_one text-center dark_color">
                   <div class="title_sections">
                      <div class="before_title">Dedicated Team</div>
                      <h2>Professional Individuals</h2>
                   </div>
                   <!--===============spacing==============-->
                   <div class="pd_bottom_20"></div>
                   <!--===============spacing==============-->
                </div>
             </div>
          </div>
          <div class="row">
<?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


             <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <div class="team_box style_one">
                   <div class="team_box_outer">
                      <div class="member_image">
                         <img src="<?php echo e(asset('images/'.$item->image)); ?>" alt="team image" />
                      </div>
                      <div class="about_member">
                         <div class="share_media">
                            <ul class="first">
                               <li class="text">Share</li>
                               <li><i class="fa fa-share-alt"></i></li>
                            </ul>
                            <ul>
                               <li class="shar_alt"><i class="fa fa-share-alt"></i></li>
                               <li><a href="<?php echo e($item->facebook); ?>" target=_blank> <i class="fa fa-facebook"> </i> </a></li>
                               <li><a href="<?php echo e($item->twitter); ?>" target=_blank> <i class="fa fa-twitter"> </i> </a></li>
                               <li><a href="<?php echo e($item->skype); ?>" target=_blank> <i class="fa fa-skype"> </i> </a></li>
                               <li><a href="<?php echo e($item->instragram); ?>" target=_blank> <i class="fa fa-instagram"> </i> </a></li>
                            </ul>
                         </div>
                         <div class="authour_details">
                            <span><?php echo e($item->employee_id); ?></span>
                            <h6><?php echo e($item->name); ?></h6>

                         </div>
                      </div>
                   </div>
                </div>
             </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
       </div>
       <!--===============spacing==============-->
       <div class="pd_bottom_70"></div>
       <!--===============spacing==============-->
    </section>


 </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rizah\resources\views/frontend/managment.blade.php ENDPATH**/ ?>