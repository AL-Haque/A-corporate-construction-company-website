<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('admin.Alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- partial -->
    <?php echo $__env->make('errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Video Gallery</h4>

                        <form class="forms-sample" method="POST" action="<?php echo e(route('video.store')); ?>"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group row">
                                <div class="col-sm-3" style="padding-top:.4rem">
                                    <p>Video Url</p>
                                </div>
                                <div class="col-sm-7">
                                    <input type="url" name="video_url" class="form-control" style="padding:.400rem"
                                        placeholder="Enter Video Url">
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-sm-3">
                                    <label for="file">video Image</label></div>
                                    <div class="col-sm-7">
                                    <input type="file" name="image" accept="image/*" onchange="readURL(this)" />
                                </div>
                                <img id="img-preview" src="<?php echo e(asset('images/noimage.jpg')); ?>" width="220px"
                                    height="150px" style="margin-left: 17.5rem;margin-top:1rem"/>
                            </div>

                            <button type="submit" class="btn btn-primary mr-2">Submit</button>
                            <button class="btn btn-light">Cancel</button>

                        </form>
                    </div>
                </div>

            </div>
        </div>



        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Video List</h4>

                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>id</th>
                                        <th>Image</th>
                                        <th>video</th>
                                        <th>Created</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td><img src="<?php echo e(asset('images/video/'.$item->image)); ?>" alt="Image"></td>
                                            <td>
                                                <div class="card-img-top d-none d-md-block" style="height: 150%;">
                                                    <iframe width="100%" height="100%" src="<?php echo e($item->video_url); ?>"
                                                        title="YouTube video player" frameborder="0"
                                                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                                        allowfullscreen></iframe>
                                                </div>
                                            </td>
                                            <td><?php echo e($item->created_at); ?></td>
                                            <td> <a href="<?php echo e(route('video.edit', $item->id)); ?>"><i
                                                class="fa-solid fa-pen"></i> </a></td>
                                            <td><a href="<?php echo e(route('video.delete', $item->id)); ?>" onclick=" return confirm('Are You Sure!') "><i
                                                class="fa-solid fa-trash"></i></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php echo $videos->withQueryString()->links('pagination::bootstrap-5'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('admin-js'); ?>
<script>
    let noimage =
        "https://ami-sni.com/wp-content/themes/consultix/images/no-image-found-360x250.png";

    function readURL(input) {
        console.log(input.files);
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                $("#img-preview").attr("src", e.target.result);
            };

            reader.readAsDataURL(input.files[0]);
        } else {
            $("#img-preview").attr("src", noimage);
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rizah\resources\views/video/index.blade.php ENDPATH**/ ?>