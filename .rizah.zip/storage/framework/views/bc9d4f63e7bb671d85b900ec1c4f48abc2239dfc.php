<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo e($info->name); ?></title>
    <!-- base:css -->
    <link rel="stylesheet" href="<?php echo e(asset('vendors/typicons.font/font/typicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendors/css/vendor.bundle.base.css')); ?>">
    <!-- endinject -->
    <!-- plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/vertical-layout-light/style.css')); ?>">

    <!-- endinject -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.png')); ?>" />
    
    <link rel="stylesheet" href="<?php echo e(asset('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css')); ?>"
     integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />



</head>

<body id="page-top">


    <div class="container-scroller">
        <?php echo $__env->make('partials.navBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">

            <?php echo $__env->make('partials.leftPanel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>

                <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>




    <!-- base:js -->
    <script src="<?php echo e(asset('vendors/js/vendor.bundle.base.js')); ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page-->
    <!-- End plugin js for this page-->
    <!-- inject:js -->
    <script src="<?php echo e(asset('js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(asset('js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('js/template.js')); ?>"></script>
    <script src="<?php echo e(asset('js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('js/todolist.js')); ?>"></script>
    <!-- endinject -->
    <!-- plugin js for this page -->
    <script src="<?php echo e(asset('vendors/progressbar.js/progressbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/chart.js/Chart.min.js')); ?>"></script>
    <!-- End plugin js for this page -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('admin-js'); ?>
    <!-- End custom js for this page-->
</body>

</html>
<?php /**PATH C:\xampp\htdocs\rizah\resources\views/layouts/adminLayout.blade.php ENDPATH**/ ?>